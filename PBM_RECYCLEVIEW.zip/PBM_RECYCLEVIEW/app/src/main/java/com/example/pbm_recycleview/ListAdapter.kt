package com.example.pbm_recycleview

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

//extend ke class rvadapter

class ListAdapter :RecyclerView.Adapter<ListAdapter.ListHolder>(){
    class ListHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListAdapter.ListHolder {
        TODO("Not yet implemented")
    }

    override fun onBindViewHolder(holder: ListAdapter.ListHolder, position: Int) {
        TODO("Not yet implemented")
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
    }
}